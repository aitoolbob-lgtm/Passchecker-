import styles from './SuggestionsPanel.module.css';

export default function SuggestionsPanel({ suggestions }) {
  if (!suggestions || suggestions.length === 0) {
    return (
      <div className={styles.allGood}>
        <div className={styles.checkIcon}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <path d="M5 12l5 5L20 7" stroke="#00ff88" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
        <div>
          <div className={styles.allGoodTitle}>All checks passed!</div>
          <div className={styles.allGoodSub}>Your password meets all security criteria</div>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <span className={styles.title}>Suggestions</span>
        <span className={styles.count}>{suggestions.length} improvement{suggestions.length !== 1 ? 's' : ''}</span>
      </div>
      <ul className={styles.list}>
        {suggestions.map((s, i) => (
          <li key={i} className={styles.item}>
            <div className={styles.arrow}>→</div>
            <span>{s}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

import styles from './StrengthMeter.module.css';

const LEVELS = {
  'Weak': { pct: 15, cls: 'weak', color: '#ff3366' },
  'Fair': { pct: 35, cls: 'fair', color: '#ff6b35' },
  'Good': { pct: 58, cls: 'good', color: '#ffb700' },
  'Strong': { pct: 80, cls: 'strong', color: '#00cc6a' },
  'Very Strong': { pct: 100, cls: 'very-strong', color: '#00ff88' },
};

export default function StrengthMeter({ result, password }) {
  if (!result || !password) {
    return (
      <div className={styles.container}>
        <div className={styles.emptyState}>
          <div className={styles.emptyIcon}>🔐</div>
          <p>Enter a password above to analyze its strength</p>
        </div>
      </div>
    );
  }

  const level = LEVELS[result.strength] || LEVELS['Weak'];

  return (
    <div className={styles.container}>
      <div className={styles.topRow}>
        <div>
          <div className={styles.strengthText} style={{ color: level.color }}>
            {result.strength}
          </div>
          <div className={styles.crackTime}>
            Crack time: <span style={{ color: level.color }}>{result.crackTime}</span>
          </div>
        </div>
        <div className={styles.scoreCircle} style={{ '--score-color': level.color }}>
          <svg viewBox="0 0 60 60" className={styles.scoreRing}>
            <circle cx="30" cy="30" r="26" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="4"/>
            <circle
              cx="30" cy="30" r="26"
              fill="none"
              stroke={level.color}
              strokeWidth="4"
              strokeLinecap="round"
              strokeDasharray={`${163.4 * result.score / 100} 163.4`}
              strokeDashoffset="40.85"
              style={{ filter: `drop-shadow(0 0 6px ${level.color}80)` }}
            />
          </svg>
          <div className={styles.scoreNumber}>{result.score}</div>
        </div>
      </div>

      <div className={styles.barTrack}>
        <div
          className={styles.barFill}
          style={{
            width: `${level.pct}%`,
            background: level.color,
            boxShadow: `0 0 12px ${level.color}60`
          }}
        />
      </div>

      <div className={styles.metrics}>
        <div className={styles.metric}>
          <span className={styles.metricLabel}>Entropy</span>
          <span className={styles.metricVal} style={{ color: level.color }}>{result.entropy} <small>bits</small></span>
        </div>
        <div className={styles.metric}>
          <span className={styles.metricLabel}>Length</span>
          <span className={styles.metricVal}>{result.length} <small>chars</small></span>
        </div>
        <div className={styles.metric}>
          <span className={styles.metricLabel}>Charset</span>
          <span className={styles.metricVal}>{result.charPool}</span>
        </div>
        <div className={styles.metric}>
          <span className={styles.metricLabel}>Rules</span>
          <span className={styles.metricVal}>{result.rulesPassed}<small>/{result.rulesTotal}</small></span>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import styles from './Navbar.module.css';

export default function Navbar() {
  const { user, logout } = useAuth();
  const { addToast } = useToast();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    addToast('Logged out successfully', 'info');
    setMenuOpen(false);
  };

  const isActive = (path) => location.pathname === path ? 'active' : '';

  return (
    <nav className={styles.nav}>
      <div className={styles.inner}>
        <Link to="/" className={styles.logo}>
          <div className={styles.logoIcon}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <rect x="3" y="11" width="18" height="11" rx="2" stroke="currentColor" strokeWidth="2"/>
              <path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              <circle cx="12" cy="16" r="1.5" fill="currentColor"/>
            </svg>
          </div>
          <span className={styles.logoText}>Pass<span className={styles.logoAccent}>Findexx</span></span>
        </Link>

        <div className={`${styles.links} hide-mobile`}>
          <Link to="/" className={`nav-link ${isActive('/')}`}>Analyzer</Link>
          <Link to="/generator" className={`nav-link ${isActive('/generator')}`}>Generator</Link>
          {user && <Link to="/dashboard" className={`nav-link ${isActive('/dashboard')}`}>Dashboard</Link>}
          <Link to="/about" className={`nav-link ${isActive('/about')}`}>About</Link>
        </div>

        <div className={styles.actions}>
          {user ? (
            <div className={styles.userMenu}>
              <span className={styles.username}>
                <span className={styles.userDot}></span>
                {user.username}
              </span>
              <button className="btn btn-ghost" onClick={handleLogout} style={{padding:'8px 16px',fontSize:'13px'}}>
                Sign Out
              </button>
            </div>
          ) : (
            <div className={styles.authBtns}>
              <Link to="/login" className="btn btn-ghost" style={{padding:'8px 16px',fontSize:'13px'}}>Sign In</Link>
              <Link to="/register" className="btn btn-primary" style={{padding:'8px 16px',fontSize:'13px'}}>Get Started</Link>
            </div>
          )}

          <button className={styles.hamburger} onClick={() => setMenuOpen(!menuOpen)}>
            <span></span><span></span><span></span>
          </button>
        </div>
      </div>

      {menuOpen && (
        <div className={styles.mobileMenu}>
          <Link to="/" className="nav-link" onClick={() => setMenuOpen(false)}>Analyzer</Link>
          <Link to="/generator" className="nav-link" onClick={() => setMenuOpen(false)}>Generator</Link>
          {user && <Link to="/dashboard" className="nav-link" onClick={() => setMenuOpen(false)}>Dashboard</Link>}
          <Link to="/about" className="nav-link" onClick={() => setMenuOpen(false)}>About</Link>
          {!user && <Link to="/login" className="nav-link" onClick={() => setMenuOpen(false)}>Sign In</Link>}
          {!user && <Link to="/register" className="nav-link" onClick={() => setMenuOpen(false)}>Get Started</Link>}
          {user && <button className="nav-link btn" style={{border:'none',background:'none',textAlign:'left',color:'var(--accent-red)'}} onClick={handleLogout}>Sign Out</button>}
        </div>
      )}
    </nav>
  );
}

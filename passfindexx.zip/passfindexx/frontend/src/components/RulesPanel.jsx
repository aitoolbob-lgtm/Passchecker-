import styles from './RulesPanel.module.css';

const RULE_ICONS = {
  minLength: '📏', hasUpper: '🔠', hasLower: '🔡', hasNumber: '🔢',
  hasSpecial: '✦', notCommon: '🛡', noRepeats: '🔁', noSequences: '⌨',
  goodLength: '📐', excellentLength: '🏆', noLeet: '🤖', uniqueChars: '🎯'
};

export default function RulesPanel({ rules }) {
  if (!rules) return null;

  const entries = Object.entries(rules);
  const passed = entries.filter(([, v]) => v.pass).length;

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <span className={styles.title}>Security Rules</span>
        <span className={styles.counter}>
          <span className={styles.passCount}>{passed}</span>
          <span className={styles.totalCount}>/{entries.length}</span>
        </span>
      </div>

      <div className={styles.progressBar}>
        <div
          className={styles.progressFill}
          style={{ width: `${(passed / entries.length) * 100}%` }}
        />
      </div>

      <div className={styles.grid}>
        {entries.map(([key, val]) => (
          <div key={key} className={`${styles.rule} ${val.pass ? styles.pass : styles.fail}`}>
            <div className={styles.ruleIcon}>
              {val.pass
                ? <svg width="14" height="14" viewBox="0 0 16 16"><path d="M3 8l3.5 3.5L13 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none"/></svg>
                : <svg width="14" height="14" viewBox="0 0 16 16"><path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" fill="none"/></svg>
              }
            </div>
            <span className={styles.ruleLabel}>{val.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

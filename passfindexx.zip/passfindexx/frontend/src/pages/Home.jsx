import { useState, useCallback, useRef } from 'react';
import api from '../utils/api';
import { useToast } from '../hooks/useToast';
import StrengthMeter from '../components/StrengthMeter';
import RulesPanel from '../components/RulesPanel';
import SuggestionsPanel from '../components/SuggestionsPanel';
import styles from './Home.module.css';

const SESSION_ID = Math.random().toString(36).slice(2);

let debounceTimer;

export default function Home() {
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const { addToast } = useToast();

  const analyze = useCallback(async (pw) => {
    if (!pw) { setResult(null); return; }
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(async () => {
      setLoading(true);
      try {
        const { data } = await api.post('/passwords/analyze', { password: pw, sessionId: SESSION_ID });
        setResult(data.result);
      } catch {
        setResult(null);
      } finally {
        setLoading(false);
      }
    }, 300);
  }, []);

  const handleChange = (e) => {
    const val = e.target.value;
    setPassword(val);
    analyze(val);
  };

  const copyPassword = async () => {
    if (!password) return;
    try {
      await navigator.clipboard.writeText(password);
      addToast('Password copied!', 'success');
    } catch {
      addToast('Copy failed', 'error');
    }
  };

  const clearPassword = () => {
    setPassword('');
    setResult(null);
  };

  const getStrengthClass = () => {
    if (!result) return '';
    return `strength-${result.strength.toLowerCase().replace(' ', '-')}`;
  };

  return (
    <div className={styles.page}>
      {/* Hero */}
      <div className={styles.hero}>
        <div className={styles.heroBadge}>
          <span className="badge badge-cyan">AI-Powered Analysis</span>
        </div>
        <h1 className={styles.heroTitle}>
          Is Your Password<br />
          <span className={styles.heroAccent}>Strong Enough?</span>
        </h1>
        <p className={styles.heroSub}>
          Real-time password intelligence — entropy, crack time, breach patterns & more
        </p>
      </div>

      <div className={styles.layout}>
        {/* Left: Input + Results */}
        <div className={styles.mainCol}>
          {/* Password input card */}
          <div className="glass-card" style={{ padding: '28px' }}>
            <label className="form-label">Your Password</label>
            <div className={styles.inputRow}>
              <input
                type={showPw ? 'text' : 'password'}
                className={`form-input ${styles.pwInput}`}
                placeholder="Type or paste your password here…"
                value={password}
                onChange={handleChange}
                autoComplete="off"
                spellCheck={false}
              />
              <div className={styles.inputActions}>
                {loading && <div className="spinner" style={{ width: 16, height: 16 }} />}
                {password && (
                  <button className={styles.iconBtn} onClick={clearPassword} title="Clear">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
                  </button>
                )}
                <button className={styles.iconBtn} onClick={() => setShowPw(v => !v)} title="Toggle visibility">
                  {showPw
                    ? <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                    : <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                  }
                </button>
                {password && (
                  <button className={styles.iconBtn} onClick={copyPassword} title="Copy">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
                  </button>
                )}
              </div>
            </div>

            {/* Character display */}
            {password && (
              <div className={styles.charDisplay}>
                {password.split('').map((ch, i) => {
                  let cls = styles.charNeutral;
                  if (/[A-Z]/.test(ch)) cls = styles.charUpper;
                  else if (/[a-z]/.test(ch)) cls = styles.charLower;
                  else if (/[0-9]/.test(ch)) cls = styles.charNum;
                  else cls = styles.charSpecial;
                  return <span key={i} className={`${styles.char} ${cls}`}>{showPw ? ch : '•'}</span>;
                })}
              </div>
            )}
          </div>

          {/* Strength Meter */}
          <div className="glass-card" style={{ padding: '28px' }}>
            <StrengthMeter result={result} password={password} />
          </div>

          {/* Suggestions */}
          {result && (
            <div className="glass-card" style={{ padding: '28px' }}>
              <SuggestionsPanel suggestions={result.suggestions} />
            </div>
          )}
        </div>

        {/* Right: Rules */}
        <div className={styles.sideCol}>
          <div className="glass-card" style={{ padding: '24px', position: 'sticky', top: '84px' }}>
            <RulesPanel rules={result?.rules} />

            {!result && (
              <div className={styles.sideHint}>
                <div className={styles.hintGrid}>
                  {['Length', 'Uppercase', 'Lowercase', 'Numbers', 'Symbols', 'Uniqueness'].map(h => (
                    <div key={h} className={styles.hintItem}>
                      <div className={styles.hintDot} />
                      <span>{h}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Tips card */}
          <div className="glass-card" style={{ padding: '24px', marginTop: '16px' }}>
            <div className={styles.tipsTitle}>Pro Tips</div>
            <div className={styles.tipsList}>
              {[
                { icon: '🎲', tip: 'Use random passphrases: 4+ unrelated words' },
                { icon: '🔢', tip: 'Mix numbers and symbols in unexpected places' },
                { icon: '🚫', tip: 'Never reuse passwords across accounts' },
                { icon: '🗝️', tip: 'Use a password manager for storage' },
              ].map((t, i) => (
                <div key={i} className={styles.tipItem}>
                  <span className={styles.tipIcon}>{t.icon}</span>
                  <span className={styles.tipText}>{t.tip}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import styles from './Auth.module.css';

export default function Register() {
  const [form, setForm] = useState({ email: '', username: '', password: '', confirm: '' });
  const [errors, setErrors] = useState({});
  const { register, loading } = useAuth();
  const { addToast } = useToast();
  const navigate = useNavigate();

  const validate = () => {
    const e = {};
    if (!form.email || !/\S+@\S+\.\S+/.test(form.email)) e.email = 'Valid email required';
    if (!form.username || form.username.length < 3) e.username = 'Username must be 3+ characters';
    if (!form.password || form.password.length < 8) e.password = 'Password must be 8+ characters';
    if (form.password !== form.confirm) e.confirm = 'Passwords do not match';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    if (!validate()) return;
    const res = await register(form.email, form.username, form.password);
    if (res.success) {
      addToast('Account created!', 'success');
      navigate('/dashboard');
    } else {
      addToast(res.error, 'error');
      setErrors({ general: res.error });
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.card}>
        <div className={styles.cardTop}>
          <div className={styles.lockIcon}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <h1 className={styles.title}>Get Started</h1>
          <p className={styles.sub}>Create your PassFindexx account</p>
        </div>

        {errors.general && <div className={styles.errorBanner}>{errors.general}</div>}

        <form onSubmit={handleSubmit} className={styles.form}>
          <div>
            <label className="form-label">Email Address</label>
            <input className={`form-input ${errors.email ? styles.inputError : ''}`} type="email" placeholder="you@example.com"
              value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} />
            {errors.email && <span className={styles.fieldError}>{errors.email}</span>}
          </div>
          <div>
            <label className="form-label">Username</label>
            <input className={`form-input ${errors.username ? styles.inputError : ''}`} type="text" placeholder="cooluser123"
              value={form.username} onChange={e => setForm(p => ({ ...p, username: e.target.value }))} />
            {errors.username && <span className={styles.fieldError}>{errors.username}</span>}
          </div>
          <div>
            <label className="form-label">Password</label>
            <input className={`form-input ${errors.password ? styles.inputError : ''}`} type="password" placeholder="Choose a strong password"
              value={form.password} onChange={e => setForm(p => ({ ...p, password: e.target.value }))} autoComplete="new-password" />
            {errors.password && <span className={styles.fieldError}>{errors.password}</span>}
          </div>
          <div>
            <label className="form-label">Confirm Password</label>
            <input className={`form-input ${errors.confirm ? styles.inputError : ''}`} type="password" placeholder="Repeat your password"
              value={form.confirm} onChange={e => setForm(p => ({ ...p, confirm: e.target.value }))} autoComplete="new-password" />
            {errors.confirm && <span className={styles.fieldError}>{errors.confirm}</span>}
          </div>

          <button type="submit" className="btn btn-success" style={{ width: '100%', marginTop: 8, padding: '14px' }} disabled={loading}>
            {loading ? <><div className="spinner" />Creating account…</> : 'Create Account →'}
          </button>
        </form>

        <div className={styles.footer}>
          Already have an account?{' '}
          <Link to="/login" className={styles.link}>Sign in →</Link>
        </div>
      </div>
    </div>
  );
}

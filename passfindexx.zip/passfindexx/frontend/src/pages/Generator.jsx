import { useState } from 'react';
import api from '../utils/api';
import { useToast } from '../hooks/useToast';
import styles from './Generator.module.css';

export default function Generator() {
  const [length, setLength] = useState(18);
  const [options, setOptions] = useState({ upper: true, lower: true, numbers: true, special: true });
  const [generated, setGenerated] = useState([]);
  const [loading, setLoading] = useState(false);
  const { addToast } = useToast();

  const generate = async (count = 1) => {
    setLoading(true);
    try {
      const results = await Promise.all(
        Array.from({ length: count }, () =>
          api.post('/passwords/generate', { length, ...options })
        )
      );
      const newPasswords = results.map(r => r.data);
      setGenerated(prev => [...newPasswords, ...prev].slice(0, 20));
    } catch {
      addToast('Generation failed', 'error');
    } finally {
      setLoading(false);
    }
  };

  const copy = async (pw) => {
    try {
      await navigator.clipboard.writeText(pw);
      addToast('Password copied!', 'success');
    } catch {
      addToast('Copy failed', 'error');
    }
  };

  const getStrengthColor = (strength) => {
    const map = { 'Weak': '#ff3366', 'Fair': '#ff6b35', 'Good': '#ffb700', 'Strong': '#00cc6a', 'Very Strong': '#00ff88' };
    return map[strength] || '#888';
  };

  const getStrengthPct = (strength) => {
    const map = { 'Weak': 15, 'Fair': 35, 'Good': 58, 'Strong': 80, 'Very Strong': 100 };
    return map[strength] || 0;
  };

  return (
    <div className={styles.page}>
      <div className={styles.hero}>
        <h1 className={styles.title}>Password <span className={styles.accent}>Generator</span></h1>
        <p className={styles.sub}>Craft uncrackable passwords with custom rules</p>
      </div>

      <div className={styles.layout}>
        {/* Controls */}
        <div className={styles.controls}>
          <div className="glass-card" style={{ padding: '28px' }}>
            <div className={styles.section}>
              <div className={styles.sectionHeader}>
                <label className="form-label" style={{ margin: 0 }}>Password Length</label>
                <span className={styles.lengthVal}>{length}</span>
              </div>
              <input
                type="range"
                min="8" max="64" step="1"
                value={length}
                onChange={e => setLength(Number(e.target.value))}
                style={{ marginTop: 8 }}
              />
              <div className={styles.rangeLabels}>
                <span>8</span><span>36</span><span>64</span>
              </div>
            </div>

            <div className={styles.divider} />

            <div className={styles.section}>
              <label className="form-label">Character Types</label>
              <div className={styles.optionsList}>
                {[
                  { key: 'upper', label: 'Uppercase Letters', desc: 'A–Z', color: '#00e5ff' },
                  { key: 'lower', label: 'Lowercase Letters', desc: 'a–z', color: '#c8d0ff' },
                  { key: 'numbers', label: 'Numbers', desc: '0–9', color: '#ffb700' },
                  { key: 'special', label: 'Special Characters', desc: '!@#$%…', color: '#00ff88' },
                ].map(({ key, label, desc, color }) => (
                  <label key={key} className={styles.optionItem}>
                    <div className={styles.optionCheck}>
                      <input
                        type="checkbox"
                        checked={options[key]}
                        onChange={e => setOptions(prev => ({ ...prev, [key]: e.target.checked }))}
                      />
                    </div>
                    <div className={styles.optionInfo}>
                      <span className={styles.optionLabel}>{label}</span>
                      <span className={styles.optionDesc} style={{ color }}>{desc}</span>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            <div className={styles.divider} />

            <div className={styles.generateBtns}>
              <button
                className="btn btn-primary"
                onClick={() => generate(1)}
                disabled={loading}
                style={{ flex: 1 }}
              >
                {loading ? <><div className="spinner" />Generating…</> : '⚡ Generate'}
              </button>
              <button
                className="btn btn-ghost"
                onClick={() => generate(5)}
                disabled={loading}
                style={{ flex: 1 }}
              >
                Generate ×5
              </button>
            </div>
          </div>

          {/* Legend */}
          <div className="glass-card" style={{ padding: '20px', marginTop: '16px' }}>
            <div className={styles.legend}>
              <div className={styles.legendTitle}>Color Legend</div>
              {[
                { color: '#00e5ff', label: 'Uppercase' },
                { color: '#c8d0ff', label: 'Lowercase' },
                { color: '#ffb700', label: 'Numbers' },
                { color: '#00ff88', label: 'Symbols' },
              ].map(({ color, label }) => (
                <div key={label} className={styles.legendItem}>
                  <div className={styles.legendDot} style={{ background: color }} />
                  <span>{label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Results */}
        <div className={styles.results}>
          {generated.length === 0 ? (
            <div className={styles.empty}>
              <div className={styles.emptyIcon}>🎲</div>
              <p>Click Generate to create passwords</p>
              <p className={styles.emptyHint}>All passwords are analyzed for strength instantly</p>
            </div>
          ) : (
            <div className={styles.passwordList}>
              {generated.map((item, i) => {
                const color = getStrengthColor(item.analysis?.strength);
                const pct = getStrengthPct(item.analysis?.strength);
                return (
                  <div key={i} className={styles.pwCard}>
                    <div className={styles.pwCardTop}>
                      <div className={styles.pwText}>
                        {item.password.split('').map((ch, j) => {
                          let color = 'var(--text-secondary)';
                          if (/[A-Z]/.test(ch)) color = '#00e5ff';
                          else if (/[a-z]/.test(ch)) color = '#c8d0ff';
                          else if (/[0-9]/.test(ch)) color = '#ffb700';
                          else color = '#00ff88';
                          return <span key={j} style={{ color }}>{ch}</span>;
                        })}
                      </div>
                      <button className={styles.copyBtn} onClick={() => copy(item.password)}>
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <rect x="9" y="9" width="13" height="13" rx="2"/>
                          <path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/>
                        </svg>
                        Copy
                      </button>
                    </div>
                    <div className={styles.pwMeta}>
                      <div className={styles.pwBarTrack}>
                        <div className={styles.pwBarFill} style={{ width: `${pct}%`, background: color }} />
                      </div>
                      <div className={styles.pwMetaRight}>
                        <span style={{ color }}>{item.analysis?.strength}</span>
                        <span className={styles.pwScore}>{item.analysis?.score}/100</span>
                        <span className={styles.pwEntropy}>{item.analysis?.entropy}b</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

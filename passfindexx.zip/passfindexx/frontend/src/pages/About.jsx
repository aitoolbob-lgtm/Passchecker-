import { Link } from 'react-router-dom';
import styles from './About.module.css';

export default function About() {
  return (
    <div className={styles.page}>
      <div className={styles.hero}>
        <h1 className={styles.title}>About <span className={styles.accent}>PassFindexx</span></h1>
        <p className={styles.sub}>The intelligent password security platform</p>
      </div>

      <div className={styles.content}>
        <div className={styles.featureGrid}>
          {[
            { icon: '⚡', title: 'Real-Time Analysis', desc: 'Instant password strength evaluation as you type with sub-300ms response time.' },
            { icon: '🔬', title: 'Entropy Calculation', desc: 'Mathematical entropy analysis based on character pool size and password length.' },
            { icon: '🛡', title: '12 Security Rules', desc: 'Comprehensive rule engine covering length, complexity, patterns, and common passwords.' },
            { icon: '⏱', title: 'Crack Time Estimation', desc: 'Estimated time to crack at 10 billion guesses per second using modern hardware.' },
            { icon: '🎲', title: 'Secure Generator', desc: 'Cryptographically random password generation with customizable character sets.' },
            { icon: '📊', title: 'Analytics Dashboard', desc: 'Track your password hygiene history and improvement over time.' },
          ].map((f, i) => (
            <div key={i} className={styles.feature}>
              <div className={styles.featureIcon}>{f.icon}</div>
              <h3 className={styles.featureTitle}>{f.title}</h3>
              <p className={styles.featureDesc}>{f.desc}</p>
            </div>
          ))}
        </div>

        <div className={styles.techStack}>
          <div className={styles.sectionTitle}>Tech Stack</div>
          <div className={styles.techGrid}>
            {[
              { cat: 'Frontend', items: ['React 18', 'React Router', 'CSS Modules', 'Vite'] },
              { cat: 'Backend', items: ['Node.js', 'Express.js', 'JWT Auth', 'Rate Limiting'] },
              { cat: 'Database', items: ['SQLite (WAL)', 'better-sqlite3', 'bcryptjs', 'UUID'] },
              { cat: 'Security', items: ['Helmet.js', 'CORS', 'Password Hashing', 'Input Validation'] },
            ].map((t, i) => (
              <div key={i} className={styles.techCard}>
                <div className={styles.techCat}>{t.cat}</div>
                {t.items.map(item => (
                  <div key={item} className={styles.techItem}>
                    <div className={styles.techDot} />
                    {item}
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>

        <div className={styles.cta}>
          <h2 className={styles.ctaTitle}>Start Securing Your Passwords</h2>
          <p className={styles.ctaSub}>Free to use. No credit card required.</p>
          <div className={styles.ctaBtns}>
            <Link to="/" className="btn btn-primary" style={{ padding: '14px 28px', fontSize: 15 }}>Analyze a Password</Link>
            <Link to="/register" className="btn btn-ghost" style={{ padding: '14px 28px', fontSize: 15 }}>Create Account</Link>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../utils/api';
import { useAuth } from '../hooks/useAuth';
import styles from './Dashboard.module.css';

export default function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [history, setHistory] = useState({ checks: [], generated: [] });
  const [globalStats, setGlobalStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [s, h, g] = await Promise.all([
          api.get('/passwords/stats'),
          api.get('/passwords/history'),
          api.get('/passwords/global-stats'),
        ]);
        setStats(s.data);
        setHistory(h.data);
        setGlobalStats(g.data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const formatDate = (ts) => {
    const d = new Date(ts * 1000);
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  const getStrengthColor = (s) => {
    const m = { 'Weak': '#ff3366', 'Fair': '#ff6b35', 'Good': '#ffb700', 'Strong': '#00cc6a', 'Very Strong': '#00ff88' };
    return m[s] || '#888';
  };

  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh', gap: 12, color: 'var(--text-secondary)' }}>
      <div className="spinner" />Loading your dashboard…
    </div>
  );

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Dashboard</h1>
          <p className={styles.sub}>Welcome back, <span className={styles.username}>{user?.username}</span></p>
        </div>
        <div className={styles.headerActions}>
          <Link to="/" className="btn btn-primary" style={{ fontSize: 13, padding: '10px 20px' }}>+ Analyze Password</Link>
          <Link to="/generator" className="btn btn-ghost" style={{ fontSize: 13, padding: '10px 20px' }}>Generate</Link>
        </div>
      </div>

      {/* Your stats */}
      <div className={styles.section}>
        <div className={styles.sectionTitle}>Your Statistics</div>
        <div className={styles.statsGrid}>
          <div className="stat-card">
            <div className="stat-value">{stats?.totalChecked || 0}</div>
            <div className="stat-label">Passwords Analyzed</div>
          </div>
          <div className="stat-card">
            <div className="stat-value" style={{ color: stats?.averageScore >= 70 ? '#00ff88' : stats?.averageScore >= 50 ? '#ffb700' : '#ff3366' }}>
              {stats?.averageScore || 0}
            </div>
            <div className="stat-label">Average Score</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">{stats?.totalGenerated || 0}</div>
            <div className="stat-label">Passwords Generated</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">
              {stats?.byStrength?.find(s => s.strength_label === 'Very Strong')?.count || 0}
            </div>
            <div className="stat-label">Very Strong Passwords</div>
          </div>
        </div>
      </div>

      {/* Strength breakdown */}
      {stats?.byStrength?.length > 0 && (
        <div className={styles.section}>
          <div className={styles.sectionTitle}>Strength Breakdown</div>
          <div className="glass-card" style={{ padding: '24px' }}>
            <div className={styles.breakdown}>
              {['Very Strong', 'Strong', 'Good', 'Fair', 'Weak'].map(s => {
                const entry = stats.byStrength.find(b => b.strength_label === s);
                const count = entry?.count || 0;
                const pct = stats.totalChecked ? Math.round(count / stats.totalChecked * 100) : 0;
                return (
                  <div key={s} className={styles.breakdownRow}>
                    <div className={styles.breakdownLabel} style={{ color: getStrengthColor(s) }}>{s}</div>
                    <div className={styles.breakdownBar}>
                      <div className={styles.breakdownFill} style={{ width: `${pct}%`, background: getStrengthColor(s) }} />
                    </div>
                    <div className={styles.breakdownCount}>{count}</div>
                    <div className={styles.breakdownPct}>{pct}%</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      <div className={styles.twoCol}>
        {/* Recent checks */}
        <div className={styles.section}>
          <div className={styles.sectionTitle}>Recent Checks</div>
          <div className="glass-card" style={{ padding: 0, overflow: 'hidden' }}>
            {history.checks.length === 0 ? (
              <div className={styles.empty}>No password checks yet</div>
            ) : (
              <div className={styles.table}>
                <div className={styles.tableHeader}>
                  <span>Strength</span><span>Score</span><span>Length</span><span>Entropy</span><span>Time</span>
                </div>
                {history.checks.slice(0, 10).map(c => (
                  <div key={c.id} className={styles.tableRow}>
                    <span style={{ color: getStrengthColor(c.strength_label), fontWeight: 600, fontSize: 13 }}>{c.strength_label}</span>
                    <span className={styles.mono} style={{ color: getStrengthColor(c.strength_label) }}>{c.score}</span>
                    <span className={styles.mono}>{c.length}</span>
                    <span className={styles.mono}>{c.entropy}b</span>
                    <span className={styles.timeCell}>{formatDate(c.created_at)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Global stats */}
        <div className={styles.section}>
          <div className={styles.sectionTitle}>Global Statistics</div>
          <div className="glass-card" style={{ padding: '24px' }}>
            <div className={styles.globalGrid}>
              <div className={styles.globalStat}>
                <div className={styles.globalVal}>{globalStats?.totalChecked?.toLocaleString() || 0}</div>
                <div className={styles.globalLabel}>Total Analyses</div>
              </div>
              <div className={styles.globalStat}>
                <div className={styles.globalVal}>{globalStats?.averageScore || 0}</div>
                <div className={styles.globalLabel}>Global Avg Score</div>
              </div>
              <div className={styles.globalStat}>
                <div className={styles.globalVal}>{globalStats?.totalGenerated?.toLocaleString() || 0}</div>
                <div className={styles.globalLabel}>Passwords Generated</div>
              </div>
            </div>
            <div className={styles.globalBreakdown}>
              {['Very Strong', 'Strong', 'Good', 'Fair', 'Weak'].map(s => {
                const entry = globalStats?.byStrength?.find(b => b.strength_label === s);
                const count = entry?.count || 0;
                return (
                  <div key={s} className={styles.globalBar} style={{ '--color': getStrengthColor(s) }}>
                    <div className={styles.globalBarLabel}>{s}</div>
                    <div className={styles.globalBarCount} style={{ color: getStrengthColor(s) }}>{count}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const COMMON_PASSWORDS = new Set([
  'password','123456','qwerty','abc123','letmein','monkey','1234567890',
  'password1','iloveyou','admin','welcome','password123','12345678',
  'sunshine','princess','football','dragon','master','superman','batman',
  'trustno1','shadow','michael','jessica','jennifer','ashley','hello',
  'charlie','donald','password2','qwerty123','iloveyou1','admin123',
  'login','passw0rd','master123','hello123','dragon1','baseball','soccer',
  '654321','superman1','qazwsx','1q2w3e','zxcvbnm','1qaz2wsx','passw0rd1'
]);

const KEYBOARD_SEQUENCES = [
  'qwerty','asdfgh','zxcvbn','qwertyuiop','asdfghjkl','zxcvbnm',
  '1234567','abcdefg','zyxwvut','poiuytr','lkjhgf','mnbvcxz',
  'qazwsx','1qaz2wsx','0987654321'
];

const LEET_MAP = { '@': 'a', '3': 'e', '1': 'i', '0': 'o', '5': 's', '7': 't', '4': 'a' };

function deLeet(pw) {
  return pw.toLowerCase().split('').map(c => LEET_MAP[c] || c).join('');
}

function calcEntropy(pw) {
  let pool = 0;
  if (/[a-z]/.test(pw)) pool += 26;
  if (/[A-Z]/.test(pw)) pool += 26;
  if (/[0-9]/.test(pw)) pool += 10;
  if (/[^a-zA-Z0-9]/.test(pw)) pool += 32;
  if (pool === 0) return 0;
  return parseFloat((pw.length * Math.log2(pool)).toFixed(2));
}

function calcCharPool(pw) {
  let pool = 0;
  if (/[a-z]/.test(pw)) pool += 26;
  if (/[A-Z]/.test(pw)) pool += 26;
  if (/[0-9]/.test(pw)) pool += 10;
  if (/[^a-zA-Z0-9]/.test(pw)) pool += 32;
  return pool;
}

function analyzePassword(password) {
  const pw = password || '';
  const lower = pw.toLowerCase();
  const deleeted = deLeet(pw);

  const rules = {
    minLength: { pass: pw.length >= 8, label: 'Minimum 8 characters', weight: 15 },
    hasUpper: { pass: /[A-Z]/.test(pw), label: 'Uppercase letter (A–Z)', weight: 12 },
    hasLower: { pass: /[a-z]/.test(pw), label: 'Lowercase letter (a–z)', weight: 12 },
    hasNumber: { pass: /[0-9]/.test(pw), label: 'At least one number', weight: 12 },
    hasSpecial: { pass: /[^a-zA-Z0-9]/.test(pw), label: 'Special character (!@#$…)', weight: 15 },
    notCommon: { pass: !COMMON_PASSWORDS.has(lower) && !COMMON_PASSWORDS.has(deleeted), label: 'Not a common password', weight: 14 },
    noRepeats: { pass: !/(.)\1{2,}/.test(pw), label: 'No excessive repeating chars', weight: 10 },
    noSequences: { pass: !KEYBOARD_SEQUENCES.some(s => lower.includes(s)), label: 'No keyboard sequences', weight: 10 },
    goodLength: { pass: pw.length >= 12, label: '12+ characters (recommended)', weight: 8 },
    excellentLength: { pass: pw.length >= 16, label: '16+ characters (excellent)', weight: 5 },
    noLeet: { pass: !COMMON_PASSWORDS.has(deleeted) || COMMON_PASSWORDS.has(lower), label: 'No simple leet substitutions', weight: 5 },
    uniqueChars: { pass: new Set(pw.split('')).size >= Math.min(pw.length * 0.6, 8), label: 'Sufficient unique characters', weight: 8 }
  };

  let score = 0;
  const totalWeight = Object.values(rules).reduce((s, r) => s + r.weight, 0);
  Object.values(rules).forEach(r => { if (r.pass) score += r.weight; });
  score = Math.round((score / totalWeight) * 100);
  if (pw.length === 0) score = 0;

  const rulesPassed = Object.values(rules).filter(r => r.pass).length;
  const rulesTotal = Object.keys(rules).length;

  const suggestions = [];
  if (!rules.minLength.pass) suggestions.push('Make it at least 8 characters long');
  if (!rules.hasUpper.pass) suggestions.push('Add uppercase letters (A–Z)');
  if (!rules.hasLower.pass) suggestions.push('Add lowercase letters (a–z)');
  if (!rules.hasNumber.pass) suggestions.push('Include at least one number (0–9)');
  if (!rules.hasSpecial.pass) suggestions.push('Add special characters like !, @, #, $, %');
  if (!rules.notCommon.pass) suggestions.push('Avoid commonly used passwords');
  if (!rules.noRepeats.pass) suggestions.push('Reduce repeated characters (e.g. aaa, 111)');
  if (!rules.noSequences.pass) suggestions.push('Remove keyboard sequences (qwerty, asdf)');
  if (!rules.goodLength.pass && pw.length >= 8) suggestions.push('Increase length to 12+ for better security');
  if (!rules.uniqueChars.pass) suggestions.push('Use more varied characters');

  let strength;
  if (score < 25) strength = 'Weak';
  else if (score < 50) strength = 'Fair';
  else if (score < 70) strength = 'Good';
  else if (score < 85) strength = 'Strong';
  else strength = 'Very Strong';

  const entropy = calcEntropy(pw);
  const charPool = calcCharPool(pw);

  const crackTime = estimateCrackTime(entropy);

  return {
    score,
    strength,
    entropy,
    charPool,
    length: pw.length,
    rules: Object.fromEntries(
      Object.entries(rules).map(([k, v]) => [k, { pass: v.pass, label: v.label }])
    ),
    rulesPassed,
    rulesTotal,
    suggestions,
    crackTime
  };
}

function estimateCrackTime(entropy) {
  if (entropy === 0) return 'Instant';
  const combinations = Math.pow(2, entropy);
  const guessesPerSecond = 1e10;
  const seconds = combinations / guessesPerSecond;
  if (seconds < 1) return 'Instant';
  if (seconds < 60) return `${Math.round(seconds)} seconds`;
  if (seconds < 3600) return `${Math.round(seconds / 60)} minutes`;
  if (seconds < 86400) return `${Math.round(seconds / 3600)} hours`;
  if (seconds < 2592000) return `${Math.round(seconds / 86400)} days`;
  if (seconds < 31536000) return `${Math.round(seconds / 2592000)} months`;
  if (seconds < 3153600000) return `${Math.round(seconds / 31536000)} years`;
  if (seconds < 3.154e13) return `${(seconds / 3153600000).toFixed(1)}K years`;
  return 'Billions of years';
}

function generatePassword(options = {}) {
  const {
    length = 18,
    upper = true,
    lower = true,
    numbers = true,
    special = true,
    memorable = false
  } = options;

  const UPPER = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const LOWER = 'abcdefghjkmnpqrstuvwxyz';
  const NUMS = '23456789';
  const SPECIAL = '!@#$%^&*-_+=?';

  let charset = '';
  let guaranteed = [];

  if (upper) { charset += UPPER; guaranteed.push(UPPER[Math.floor(Math.random() * UPPER.length)], UPPER[Math.floor(Math.random() * UPPER.length)]); }
  if (lower) { charset += LOWER; guaranteed.push(LOWER[Math.floor(Math.random() * LOWER.length)], LOWER[Math.floor(Math.random() * LOWER.length)]); }
  if (numbers) { charset += NUMS; guaranteed.push(NUMS[Math.floor(Math.random() * NUMS.length)], NUMS[Math.floor(Math.random() * NUMS.length)]); }
  if (special) { charset += SPECIAL; guaranteed.push(SPECIAL[Math.floor(Math.random() * SPECIAL.length)], SPECIAL[Math.floor(Math.random() * SPECIAL.length)]); }

  if (!charset) charset = LOWER;

  let pw = guaranteed.join('');
  while (pw.length < length) pw += charset[Math.floor(Math.random() * charset.length)];
  pw = pw.slice(0, length).split('').sort(() => Math.random() - 0.5).join('');

  return pw;
}

module.exports = { analyzePassword, generatePassword };

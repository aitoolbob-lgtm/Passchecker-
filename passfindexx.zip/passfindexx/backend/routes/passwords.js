const express = require('express');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../db/database');
const { analyzePassword, generatePassword } = require('../utils/passwordEngine');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();
router.use(authMiddleware);

// Analyze a password
router.post('/analyze', async (req, res) => {
  try {
    const { password, sessionId } = req.body;
    if (password === undefined) return res.status(400).json({ error: 'Password required' });

    const result = analyzePassword(password);

    if (password.length > 0) {
      const db = getDb();
      const hash = await bcrypt.hash(password, 6);
      const id = uuidv4();
      db.prepare(`INSERT INTO password_checks 
        (id, user_id, session_id, password_hash, score, strength_label, entropy, length, char_pool, suggestions, rules_passed, rules_total)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
        .run(
          id,
          req.user?.id || null,
          sessionId || null,
          hash,
          result.score,
          result.strength,
          result.entropy,
          result.length,
          result.charPool,
          JSON.stringify(result.suggestions),
          result.rulesPassed,
          result.rulesTotal
        );
    }

    res.json({ success: true, result });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Analysis failed' });
  }
});

// Generate a strong password
router.post('/generate', (req, res) => {
  try {
    const { length = 18, upper = true, lower = true, numbers = true, special = true, sessionId } = req.body;
    const safeLen = Math.min(Math.max(parseInt(length) || 18, 8), 64);

    const password = generatePassword({ length: safeLen, upper, lower, numbers, special });
    const analysis = analyzePassword(password);

    const db = getDb();
    const id = uuidv4();
    db.prepare(`INSERT INTO generated_passwords 
      (id, user_id, session_id, length, include_upper, include_lower, include_numbers, include_special, score)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(id, req.user?.id || null, sessionId || null, safeLen,
        upper ? 1 : 0, lower ? 1 : 0, numbers ? 1 : 0, special ? 1 : 0, analysis.score);

    res.json({ success: true, password, analysis });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Generation failed' });
  }
});

// Get user's history (requires auth)
router.get('/history', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Login required' });
  const db = getDb();
  const checks = db.prepare(`
    SELECT id, score, strength_label, entropy, length, char_pool, rules_passed, rules_total, created_at
    FROM password_checks WHERE user_id = ? ORDER BY created_at DESC LIMIT 50
  `).all(req.user.id);

  const generated = db.prepare(`
    SELECT id, length, score, created_at FROM generated_passwords
    WHERE user_id = ? ORDER BY created_at DESC LIMIT 20
  `).all(req.user.id);

  res.json({ checks, generated });
});

// Get user stats
router.get('/stats', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Login required' });
  const db = getDb();

  const total = db.prepare('SELECT COUNT(*) as count FROM password_checks WHERE user_id = ?').get(req.user.id);
  const avgScore = db.prepare('SELECT AVG(score) as avg FROM password_checks WHERE user_id = ?').get(req.user.id);
  const byStrength = db.prepare(`
    SELECT strength_label, COUNT(*) as count FROM password_checks
    WHERE user_id = ? GROUP BY strength_label
  `).all(req.user.id);
  const totalGenerated = db.prepare('SELECT COUNT(*) as count FROM generated_passwords WHERE user_id = ?').get(req.user.id);

  res.json({
    totalChecked: total.count,
    averageScore: Math.round(avgScore.avg || 0),
    byStrength,
    totalGenerated: totalGenerated.count
  });
});

// Global stats (public)
router.get('/global-stats', (req, res) => {
  const db = getDb();
  const total = db.prepare('SELECT COUNT(*) as count FROM password_checks').get();
  const avgScore = db.prepare('SELECT AVG(score) as avg FROM password_checks').get();
  const byStrength = db.prepare('SELECT strength_label, COUNT(*) as count FROM password_checks GROUP BY strength_label').all();
  const totalGen = db.prepare('SELECT COUNT(*) as count FROM generated_passwords').get();

  res.json({
    totalChecked: total.count,
    averageScore: Math.round(avgScore.avg || 0),
    byStrength,
    totalGenerated: totalGen.count
  });
});

module.exports = router;

const Database = require('better-sqlite3');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'passfindexx.db');

let db;

function getDb() {
  if (!db) {
    db = new Database(DB_PATH);
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');
    initSchema();
  }
  return db;
}

function initSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at INTEGER DEFAULT (strftime('%s','now')),
      last_login INTEGER
    );

    CREATE TABLE IF NOT EXISTS password_checks (
      id TEXT PRIMARY KEY,
      user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
      session_id TEXT,
      password_hash TEXT NOT NULL,
      score INTEGER NOT NULL,
      strength_label TEXT NOT NULL,
      entropy REAL NOT NULL,
      length INTEGER NOT NULL,
      char_pool INTEGER NOT NULL,
      suggestions TEXT NOT NULL,
      rules_passed INTEGER NOT NULL,
      rules_total INTEGER NOT NULL,
      created_at INTEGER DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS generated_passwords (
      id TEXT PRIMARY KEY,
      user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
      session_id TEXT,
      length INTEGER NOT NULL,
      include_upper INTEGER DEFAULT 1,
      include_lower INTEGER DEFAULT 1,
      include_numbers INTEGER DEFAULT 1,
      include_special INTEGER DEFAULT 1,
      score INTEGER NOT NULL,
      created_at INTEGER DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS user_sessions (
      id TEXT PRIMARY KEY,
      user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
      created_at INTEGER DEFAULT (strftime('%s','now')),
      expires_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_checks_user ON password_checks(user_id);
    CREATE INDEX IF NOT EXISTS idx_checks_session ON password_checks(session_id);
    CREATE INDEX IF NOT EXISTS idx_gen_user ON generated_passwords(user_id);
  `);
}

module.exports = { getDb };
